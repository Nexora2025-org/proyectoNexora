#!bin/bash
#apagar el firewall

source ./scripts/colores.sh
source ./scripts/firewall.sh
apagarFirewall
# Instalar paquetes
source ./scripts/installPaquetes.sh
agregarRepoEpel
instalarPaquetes
# Shell para mostrar mensajes con colores


# Crear usuarios
source ./scripts/usuarios.sh
crearUsuario "smiraglia"
crearUsuario "lnogueira"
crearUsuario "jrodriguez"

