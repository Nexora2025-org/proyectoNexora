apagarFirewall() {
    sudo systemctl stop firewalld
    sudo systemctl disable firewalld
    mensajeVerde "Firewall apagado"
}