function agregarRepoEpel() {
    if [ -e /etc/yum.repos.d/epel.repo ]; then
        mensajeAmarillo "El repositorio epel ya se encuentra instalado"
    else
        mensajeVerde "Instalando el repositorio epel"
        dnf install -y epel-release  || mensajeAmarillo "Error al instalar el repositorio EPEL"
    fi
}
function instalarPaquetes() {
    paquetes=(vim git wget curl)

    for paquete in ${paquetes[@]}; do
        if $(rpm -qa | grep $paquete &> /dev/null); then
            mensajeAmarillo "El paquete $paquete ya se encuentra instalado"
        else
            mensajeVerde "Instalando el paquete $paquete"
            dnf install -y $paquete || mensajeAmarillo "Error al instalar el paquete $paquete" #si da error mandarlo como mensaje amarillo
        fi  
    done
}