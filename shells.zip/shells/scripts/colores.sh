verde="\e[0;32m"
rojo="\e[0;31m"
azul="\e[0;34m"
amarillo="\e[0;33m"
reset="\e[0m"

function mensajeVerde() { 
    echo -e "${verde}$1${reset}"
}

function mensajeRojo() {
    echo -e "${rojo}$1${reset}"
}

function mensajeAzul() { 
    echo -e "${azul}$1${reset}"
}

function mensajeAmarillo() { 
    echo -e "${amarillo}$1${reset}"
}