crearUsuario() {
    local user="$1"
    mensajeVerde "Creando usuario $user"

    if getent passwd "$user" > /dev/null; then
        mensajeAmarillo "El usuario $user ya existe"
    else
        sudo useradd -m -g wheel "$user" > /dev/null 2>&1

        sudo passwd "$user" > /dev/null 2>&1 <<EOF
${user}123
${user}123
EOF
        sudo chage -d 0 "$user" > /dev/null 2>&1

        mensajeVerde "Se creó el usuario $user → contraseña temporal: ${user}123 (deberá cambiarla al iniciar sesión)"
    fi
}